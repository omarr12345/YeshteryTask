import React from 'react'

function AddToCart() {
  return (
    <div className='add-to-cart'>AddToCart</div>
  )
}

export default AddToCart