import React from 'react'

const SecNav = () => {
  return (
    <div>SecNav</div>
  )
}

export default SecNav