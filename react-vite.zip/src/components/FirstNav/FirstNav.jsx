import "./first-nav.scss";
import { BsMinecartLoaded } from "react-icons/bs";
import { AiOutlineHeart } from "react-icons/ai";
import { MdOutlinePersonOutline } from "react-icons/md";

const FirstNav = () => {
  return (
    <div className="first-nav">
      <div className="container">
        <div className="row my-3">
          <div className="col-md-8 text-start">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="18.219"
              viewBox="0 0 24 18.219"
              className="d"
              fill="white"
            >
              <g transform="translate(-2557.581 -332.903)">
                <path d="M2580.248,335.57h-21.334a1.333,1.333,0,0,1,0-2.667h21.334a1.333,1.333,0,0,1,0,2.667Z"></path>
                <path d="M2576.248,343.346h-17.334a1.334,1.334,0,0,1,0-2.667h17.334a1.334,1.334,0,0,1,0,2.667Z"></path>
                <path d="M2580.248,351.122h-21.334a1.333,1.333,0,0,1,0-2.666h21.334a1.333,1.333,0,0,1,0,2.666Z"></path>
              </g>
            </svg>

            <img src="../../../public/images/brand-logo-yellow.svg" />
          </div>
          <div className="col-md-4 d-flex justify-content-between">
            <button className="my-2 nav-btn-style">
              <BsMinecartLoaded className="nav-icons mx-1" size={30} />
              <span className="nav-ele-text">Cart</span>
            </button>
            <button className="my-2 nav-btn-style">
              <AiOutlineHeart className="nav-icons mx-1" size={30} />
              <span className="nav-ele-text">Wishlist</span>
            </button>
            <button className="my-2 nav-btn-style">
              <MdOutlinePersonOutline className="nav-icons mx-1" size={30} />
              <span className="nav-ele-text">Login</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FirstNav;
