import React from 'react'

const ThirdNav = () => {
  return (
    <div>ThirdNav</div>
  )
}

export default ThirdNav