// import { useState } from "react";
import FirstNav from "./components/FirstNav/FirstNav";
import Footer from "./components/Footer/Footer";
import Products from "./components/Products/Products";
import SecNav from "./components/SecNav/SecNav";
import ThirdNav from "./components/ThirdNav/ThirdNav";
import AddToCart from "./pages/AddToCart/AddToCart";
function App() {
  // const [count, setCount] = useState(0)

  return (
    <>
      <div className="app">
        <FirstNav />
        <SecNav />
        <ThirdNav />
        <AddToCart />
        <Products />
        <Footer />
      </div>
    </>
  );
}

export default App;
